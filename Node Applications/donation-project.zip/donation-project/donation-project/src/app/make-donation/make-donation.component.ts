import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-make-donation',
  templateUrl: './make-donation.component.html',
  styleUrls: ['./make-donation.component.css']
})
export class MakeDonationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
