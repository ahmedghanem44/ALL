import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-donation-mng',
  templateUrl: './donation-mng.component.html',
  styleUrls: ['./donation-mng.component.css']
})
export class DonationMngComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
